# Paint-for-Kids
A fancy colorful application to teach kids some computer skills
